python test_gen.py \
--ckpt ./logs_gen/GEN_2025_07_13__21_22_49/ckpt_0.000000_41000.pt \
--dataset_path "data/plant3d.hdf5" \
--batch_size 16 \
--num_classes 16 \
--class_label 0 \
