python train_gen.py \
--train_batch_size 16 \
--val_batch_size 16 \
--num_classes 16 \
--dataset_path "data/densenet.hdf5" 